Documentation:
get(filename without extension)
returns object from file

deposit(filename without extension, data to deposit - object of Wolvesburg class)
Preparing data:
object = Wolvesburg()
object.property = value

importtxt(filename without extension, object of Wolvesburg class)
